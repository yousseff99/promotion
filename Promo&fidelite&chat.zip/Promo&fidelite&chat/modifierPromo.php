<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    
<!-- Mirrored from html.designstream.co.in/pink-desh/dark/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 07 Nov 2019 01:40:12 GMT -->
<head>
        <title>STACA</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"><meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="fontawesome/css/font-awesome.min.css" rel="stylesheet">
        <link href="css/metisMenu.css" rel="stylesheet">
        <link href="css/morris-0.4.3.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">

        <script type="text/javascript" src="js/test.js"></script>


        <script src="js/modernizr.js"></script>
    </head>
    <body class="fixed-left">

        <div id="wrapper">

            <!--top bar-->
            <div class="topbar">
                <div class="topbar-left">
                    <div class="text-center">
                        <a href="..\..\..\..\admin\tm-shopify048-wheels.myshopify.com\index.html" class="logo"><img src="images/logo.png" alt=""></a>
                    </div>
                </div>
                <div class="pull-left menu-toggle">
                    <i class="fa fa-bars"></i>
                </div>
                <form class="pull-left app-search hidden-xs">
                    <input type="text" class="form-control" placeholder="Search here...">
                    <i class="fa fa-search"></i>
                </form>
                <ul class="nav navbar-nav  top-right-nav hidden-xs">
                    <li>

                        <span id="para2"></span>
                        <span id="para3"></span>
                        <span id="para1"></span>
                    </li>
                    <li class="dropdown  hidden-xs">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell-o"></i> <span class="badge">5</span></a>
                        <ul class="dropdown-menu dropdown-lg">
                            <li><a>Notifications (3)</a></li>
                            <li class="clearfix"><a href="#"><i class="fa fa-twitter"></i> <div class="drop-content">
                                        <h4>New Follower</h4>
                                        <span>3 New Follower</span>
                                    </div></a>
                            </li>
                            <li class="clearfix"><a href="#"><i class="fa fa-envelope-o"></i> <div class="drop-content">
                                        <h4>New Emails</h4>
                                        <span>3 New Emails</span>
                                    </div></a>
                            </li>
                            <li class="clearfix"><a href="#"><i class="fa fa-tasks"></i> <div class="drop-content">
                                        <h4>Pending tasks</h4>
                                        <span>you have 3 pending tasks</span>
                                    </div></a>
                            </li>
                            <li class="text-right"><a href="#">View All Notifications</a></li>
                        </ul>
                    </li>
                    <li class="dropdown profile-link hidden-xs">
                        <div class="clearfix">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <img src="images/admin.JPG" alt="" class="pull-left">
                                <span>Youssef selmi <br><em>Admin</em></span>                            
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="#">Account</a></li>
                                <li><a href="#">Settings</a></li>
                                <li><a href="#">Logout</a></li>
                            </ul>
                        </div>

                    </li>
                    <li class=" hidden-xs"><a href="#" id="sidebar-toggle"><i class="fa fa-comments-o"></i></a></li>
                </ul>
            </div>
            <!--end top bar-->

            <!--left menu start-->
            <div class="side-menu left" id="side-menu">

                <ul class="metismenu clearfix" id="menu">
                    <li class="profile-menu visible-xs">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <img src="images/user.png" alt="" class="pull-left">
                            <span>Sami Bhh <br><em>Admin</em></span>                            
                        </a>
                        <ul class="dropdown-menu profile-drop">
                            <li><a href="#">Account</a></li>
                            <li><a href="#">Settings</a></li>
                            <li><a href="#">Logout</a></li>
                        </ul>
                    </li>
                    <li class="active"><a href="index.html"><i class="fa fa-home"></i>  <span>Dashboard</span></a></li>  

                   <!--   place sous menu -->






                    <li>
                        <a href="ajoutPromotion.html"><i class="fa fa-sitemap"></i> <span>Promo</span><span class="fa arrow"></span></a>
                    </li>
                         <li>
                        <a href="afficherPromos.php"><i class="fa fa-sitemap"></i> <span>Listes des Promos</span><span class="fa arrow"></span></a></li>
                        <!--
                        <ul class="nav nav-second-level collapse">
                            <li>
                                <a href="#">Third Level <span class="fa arrow"></span></a>
                                <ul class="nav nav-third-level">
                                    <li>
                                        <a href="#">Third Level Item</a>
                                    </li>
                                    <li>
                                        <a href="#">Third Level Item</a>
                                    </li>
                                    <li>
                                        <a href="#">Third Level Item</a>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="#">Second Level Item</a></li>
                            <li>
                                <a href="#">Second Level Item</a></li>
                            <li>
                                <a href="#">Second Level Item</a></li>
                        </ul>
                    </li>
                </ul>
            -->
                <div class="nav-bottom clearfix">
                    <a href="#" style="border-right: 0px;"><i class="fa fa-lock"></i></a>
                    <a href="#" style="border-right: 0px;"><i class="fa fa-download"></i></a>
                    <a href="#" style="border-right: 0px;"><i class="fa fa-globe"></i></a>
                    <a href="#" style="border-right: 0px;"><i class="fa fa-phone"></i></a>
                </div>
            </div>
            <!--left menu end-->
            <div class="content-page  equal-height">
                <div class="content">
                    <div class="container">
                        <div class="page-title">
                            <h3>Ma Promotion</h3>
                            <a href="#"><i class="fa fa-plus"></i> Add Widget</a>
                            <a href="#"><i class="fa fa-share"></i> Share</a>
                            <a href="#"><i class="fa fa-envelope"></i> Email</a>
                        </div><!--end page title-->

                             <p class="promo" align="center" class="text-center text-info">Modifier Promotion</p>




<?PHP
include "promo.php";
include "promoC.php";
if (isset($_GET['id'])){
    $promoC=new PromoC();
    $result=$promoC->recupererPromo($_GET['id']);
    foreach($result as $row){
        $id=$row['id'];
        $idprod=$row['idprod'];
        $prix_nouveau=$row['prix_nouveau'];
        $description=$row['description'];
        $date_debut=$row['date_debut'];
        $date_fin=$row['date_fin'];
?>






        <form  method="POST">
                                 
        <table align="center" border="0" width="48%" height="286">


                            	 <tr>
        <td height="46" width="35%">
            <h4>  ID PROMO</h4>
        </td>
        <td width="63%" height="46"><input type="text" name="id" value="<?PHP echo $id ?>" class="form-control" placeholder="ID Promo"></td>
    </tr>
    <tr>
        <td height="46" width="35%">
            <h4>  ID PRODUIT</h4>
        </td>
        <td width="63%" height="46"><input type="text" name="idprod" value="<?PHP echo $idprod ?>" class="form-control" placeholder="ID Produit"></td>
    </tr>

     <tr>
        <td width="35%">
            <h4>NOUVEAU PRIX</h4>
        </td>
        <td width="63%"><input type="number" name="prix_nouveau" value="<?PHP echo $prix_nouveau ?>" class="form-control" placeholder="Enter Price of Promotion" ></td>
    </tr>

    <tr>
        <td width="35%">
            <h4>DESCRIPTION</h4>
        </td>
        <td width="63%"><input type="text" name="description" value="<?PHP echo $description ?>" class="form-control" required pattern="[0-9a-zA-Z-\.]{3,400}" placeholder="Informations About the products" ></td>
    </tr>

    <tr>
        <td height="46" width="35%">
        <h4>DATE DEBUT PROMOTION</h4></td>
        <td width="63%" height="46"><input type="date" name="date_debut" value="<?PHP echo $date_debut ?>"  class="form-control" placeholder="Date Start"></td>
    </tr>
    <tr>
        <td height="46" width="35%">
            <h4>DATE FIN PROMOTION</h4>
        </td>
        <td width="63%" height="46"><input type="date" name="date_fin" value="<?PHP echo $date_fin ?>"  class="form-control" placeholder="Date fin"></td>
    </tr>
   
    
    <tr>
        <td height="36" colspan="2"><input type="submit" class="btn btn-primary btn-block" name="modifier" value="modifier"></td>
    </tr>

    <tr>
<td></td>
<td><input type="hidden" name="id_ini" value="<?PHP echo $_GET['id'];?>"></td>
</tr>

</table>
 </form>
 <br><br>



<?PHP
    }
}
if (isset($_POST['modifier'])){
    $promo=new promo($_POST['id'],$_POST['idprod'],$_POST['prix_nouveau'],$_POST['description'],$_POST['date_debut'],$_POST['date_fin']);
    $promoC->modifierPromo($promo,$_POST['id_ini']);
    echo $_POST['id_ini'];
    header('Location: afficherPromos.php');
}
?>








                    <!--content-->               
                </div><!--content page-->
            </div><!--end wrapper-->
        </div>
      
    </body>

<!-- Mirrored from html.designstream.co.in/pink-desh/dark/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 07 Nov 2019 01:40:58 GMT -->
</html>
